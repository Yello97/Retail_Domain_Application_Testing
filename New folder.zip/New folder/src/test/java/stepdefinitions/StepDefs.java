package stepdefinitions;

import io.cucumber.java.en.*;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import org.testng.Assert;
import pages.*;

public class StepDefs {

    HomePage home = new HomePage(Hooks.driver);
    RegisterPage register = new RegisterPage(Hooks.driver);
    ProductPage product = new ProductPage(Hooks.driver);
    CartPage cart = new CartPage(Hooks.driver);

    @Given("user is on homepage")
    public void user_on_homepage() {
        Assert.assertTrue(Hooks.driver.getTitle().contains("Demo"));
    }

    @When("user registers with valid details")
    public void user_registers() {
        String email = "test" + System.currentTimeMillis() + "@mail.com";
        register.registerUser(email);
    }

    @Then("registration should be successful")
    public void verify_registration() {
        Assert.assertTrue(register.getMessage().contains("Your registration completed"));
    }

    @When("user searches for product {string}")
    public void search_product(String productName) {
        home.searchProduct(productName);
    }

    @Then("search results should be displayed")
    public void verify_search() {
        Assert.assertTrue(Hooks.driver.getTitle().contains("Search"));
    }

    @When("user adds product to cart")
    public void add_to_cart() {
        product.selectProduct();
        product.addToCart();
        product.goToCart();
    }

    @And("proceeds to checkout")
    public void checkout() {
        cart.checkout();
    }

    @Then("payment should fail or show error")
    public void payment_failure() {
        String src = Hooks.driver.getPageSource().toLowerCase();
        Assert.assertTrue(src.contains("error") || src.contains("failed"));
    }

    LoginPage login = new LoginPage(Hooks.driver);

    @When("user logs in with valid credentials")
    public void login_user() {
        login.login("testuser@gmail.com", "Password123");
    }

    @Then("login should be successful")
    public void verify_login() {
        Assert.assertTrue(login.isLoginSuccessful());
    }

    SearchPage searchPage = new SearchPage(Hooks.driver);

    @And("user applies price filter")
    public void apply_filter() {
        searchPage.applyPriceFilter();
    }

    @Then("filtered results should be shown")
    public void verify_filter() {
        Assert.assertTrue(searchPage.resultsDisplayed());
    }

    String price;

    @When("user captures cart price")
    public void capture_price() {
        price = cart.getTotalPrice();
    }

    @Then("cart price should be displayed correctly")
    public void verify_price() {
        Assert.assertNotNull(price);
    }

    @When("user applies promo code")
    public void apply_promo() {
        cart.applyPromo("DISCOUNT10");
    }

    @Then("discount should be applied or error shown")
    public void verify_discount() {
        Assert.assertTrue(cart.getDiscountMessage().length() > 0);
    }

    CheckoutPage checkout = new CheckoutPage(Hooks.driver);

    @Then("order should be placed successfully")
    public void verify_order() {
        Assert.assertTrue(checkout.getConfirmation().contains("success"));
    }

    OrderPage orderPage = new OrderPage(Hooks.driver);

    @When("user navigates to order history")
    public void go_to_orders() {
        orderPage.goToOrders();
    }

    @Then("order status should be visible")
    public void verify_order_status() {
        String page = Hooks.driver.getPageSource();

        Assert.assertTrue(
                page.contains("Pending") ||
                        page.contains("Processing") ||
                        page.contains("Completed") ||
                        page.contains("Order")
        );
    }

    @Then("product should be added successfully")
    public void verify_add_to_cart() {
        Assert.assertTrue(Hooks.driver.getPageSource().contains("Shopping cart"));
    }

    @Then("order confirmation message should be displayed")
    public void verify_email_simulation() {
        Assert.assertTrue(Hooks.driver.getPageSource().contains("order"));
    }

    @Then("all important UI elements should be visible")
    public void verify_ui_elements() {
        Assert.assertTrue(Hooks.driver.findElement(By.id("small-searchterms")).isDisplayed());
        Assert.assertTrue(Hooks.driver.findElement(By.linkText("Register")).isDisplayed());
    }

    @Then("search button should be clickable")
    public void verify_clickable() {
        Assert.assertTrue(Hooks.driver.findElement(By.xpath("//input[@value='Search']")).isEnabled());
    }

    @When("user resizes browser")
    public void resize_browser() {
        Hooks.driver.manage().window().setSize(new Dimension(768, 1024));
    }

    @Then("UI should still be usable")
    public void verify_responsive() {
        Assert.assertTrue(Hooks.driver.findElement(By.id("small-searchterms")).isDisplayed());
    }

    @Then("homepage should load within acceptable time")
    public void verify_load_time() {
        long start = System.currentTimeMillis();
        Hooks.driver.get("https://demowebshop.tricentis.com/");
        long end = System.currentTimeMillis();

        long loadTime = (end - start);
        System.out.println("Load Time: " + loadTime);

        Assert.assertTrue(loadTime < 5000); // 5 seconds
    }

    @Then("application should handle multiple users")
    public void simulate_users() {
        for (int i = 0; i < 3; i++) {
            Hooks.driver.navigate().refresh();
        }
        Assert.assertTrue(true);
    }

    @Then("payment should not be marked successful")
    public void validate_payment_bug() {
        String page = Hooks.driver.getPageSource().toLowerCase();
        Assert.assertFalse(page.contains("successfully processed"));
    }

    @Then("discount should be applied correctly")
    public void validate_discount() {
        String total = cart.getTotalPrice();
        Assert.assertNotNull(total); // basic validation
    }

    @Then("user should be able to remove item from cart")
    public void remove_item() {
        Hooks.driver.findElement(By.name("removefromcart")).click();
        Hooks.driver.findElement(By.name("updatecart")).click();

        Assert.assertTrue(Hooks.driver.getPageSource().contains("Your Shopping Cart is empty"));
    }

    @Then("all buttons should be clickable")
    public void validate_buttons() {
        Assert.assertTrue(Hooks.driver.findElement(By.xpath("//input[@value='Search']")).isEnabled());
    }

    @When("user places an order")
    public void user_places_an_order() {

        WebDriverWait wait = new WebDriverWait(Hooks.driver, Duration.ofSeconds(15));

        HomePage home = new HomePage(Hooks.driver);
        ProductPage product = new ProductPage(Hooks.driver);
        CartPage cart = new CartPage(Hooks.driver);
        LoginPage login = new LoginPage(Hooks.driver);

        // ✅ LOGIN
        login.login("testuser@gmail.com", "Password123");

        // ✅ Ensure login successful
        wait.until(ExpectedConditions.urlContains("demowebshop"));

        // ✅ Go to homepage (safe reset)
        Hooks.driver.get("https://demowebshop.tricentis.com/");

        // ✅ Search + add product
        home.searchProduct("Laptop");
        product.selectProduct();
        product.addToCart();
        product.goToCart();

        // 🔥 IMPORTANT: Accept terms before checkout
        Hooks.driver.findElement(By.id("termsofservice")).click();

        // ✅ Checkout
        Hooks.driver.findElement(By.id("checkout")).click();

        // 🔥 Ensure checkout page
        wait.until(ExpectedConditions.urlContains("checkout"));

        // 🔥 BILLING ADDRESS
        try {
            wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//div[@id='billing-buttons-container']//input[@value='Continue']")
            )).click();
        } catch (Exception ignored) {}

        // 🔥 SHIPPING ADDRESS
        try {
            wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//div[@id='shipping-buttons-container']//input[@value='Continue']")
            )).click();
        } catch (Exception ignored) {}

        // 🔥 SHIPPING METHOD
        try {
            wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//div[@id='shipping-method-buttons-container']//input[@value='Continue']")
            )).click();
        } catch (Exception ignored) {}

        // 🔥 PAYMENT METHOD
        wait.until(ExpectedConditions.elementToBeClickable(By.id("paymentmethod_0"))).click();

        wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//input[@onclick='PaymentMethod.save()']")
        )).click();

        // 🔥 PAYMENT INFO
        wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//div[@id='payment-info-buttons-container']//input[@value='Continue']")
        )).click();

        // 🔥 CONFIRM ORDER
        wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//input[@value='Confirm']")
        )).click();
    }
}
