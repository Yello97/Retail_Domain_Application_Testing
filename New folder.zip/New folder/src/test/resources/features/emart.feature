Feature: E-Mart Automation


  Scenario: User Login
    Given user is on homepage
    When user logs in with valid credentials
    Then login should be successful

  Scenario: User Registration
    Given user is on homepage
    When user registers with valid details
    Then registration should be successful

  Scenario: Search Product
    Given user is on homepage
    When user searches for product "Laptop"
    Then search results should be displayed

  Scenario: Payment Failure
    Given user is on homepage
    When user searches for product "Laptop"
    And user adds product to cart
    And proceeds to checkout
    Then payment should fail or show error

  Scenario: Order Tracking
    Given user is on homepage
    When user logs in with valid credentials
    And user places an order
    And user navigates to order history
    Then order status should be visible

#Functional testing
  Scenario: Verify login, search and add to cart
    Given user is on homepage
    When user logs in with valid credentials
    And user searches for product "Laptop"
    And user adds product to cart
    Then product should be added successfully

#Integration Testing

  Scenario: Payment integration failure
    Given user is on homepage
    When user searches for product "Laptop"
    And user adds product to cart
    And proceeds to checkout
    Then payment should fail or show error


