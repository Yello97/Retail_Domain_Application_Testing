package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class OrderPage {
    WebDriver driver;

    public OrderPage(WebDriver driver) {
        this.driver = driver;
    }

    By myAccount = By.linkText("My account");
    By ordersLink = By.linkText("Orders");
    By orderStatus = By.xpath("//div[@class='order-status'] | //li[contains(text(),'Order Status')] | //div[contains(text(),'Order')]");

    public void goToOrders() {
        driver.findElement(myAccount).click();
        driver.findElement(ordersLink).click();
    }

    public String getOrderStatus() {
        return driver.findElement(
                By.xpath("//*[contains(text(),'Pending') or contains(text(),'Processing') or contains(text(),'Completed')]")
        ).getText();
    }
}