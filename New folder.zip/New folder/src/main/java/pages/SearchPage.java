package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SearchPage {
    WebDriver driver;

    public SearchPage(WebDriver driver) {
        this.driver = driver;
    }

    By priceFilter = By.xpath("//input[@value='Under 25']");

    public void applyPriceFilter() {
        driver.findElement(priceFilter).click();
    }

    public boolean resultsDisplayed() {
        return driver.findElements(By.cssSelector(".product-item")).size() > 0;
    }
}