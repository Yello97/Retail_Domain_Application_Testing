package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CheckoutPage {
    WebDriver driver;

    public CheckoutPage(WebDriver driver) {
        this.driver = driver;
    }

    By confirmBtn = By.xpath("//input[@value='Confirm']");
    By successMsg = By.className("title");

    public void confirmOrder() {
        driver.findElement(confirmBtn).click();
    }

    public String getConfirmation() {
        return driver.findElement(successMsg).getText();
    }
}