package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ProductPage {
    WebDriver driver;

    public ProductPage(WebDriver driver) {
        this.driver = driver;
    }

    By product = By.cssSelector(".product-item h2 a");
    By add = By.xpath("//input[@value='Add to cart']");
    By cart = By.linkText("Shopping cart");

    public void selectProduct() {
        driver.findElement(product).click();
    }

    public void addToCart() {
        driver.findElement(add).click();
    }

    public void goToCart() {
        driver.findElement(cart).click();
    }
}
