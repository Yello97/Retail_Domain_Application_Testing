package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CartPage {
    WebDriver driver;

    public CartPage(WebDriver driver) {
        this.driver = driver;
    }

    By terms = By.id("termsofservice");
    By checkout = By.id("checkout");

    public void checkout() {
        driver.findElement(terms).click();
        driver.findElement(checkout).click();
    }

    By totalPrice = By.className("product-subtotal");

    public String getTotalPrice() {
        return driver.findElement(totalPrice).getText();
    }

    By promoBox = By.id("discountcouponcode");
    By applyBtn = By.name("applydiscountcouponcode");
    By discountMsg = By.className("message");

    public void applyPromo(String code) {
        driver.findElement(promoBox).sendKeys(code);
        driver.findElement(applyBtn).click();
    }

    public String getDiscountMessage() {
        return driver.findElement(discountMsg).getText();
    }
}
