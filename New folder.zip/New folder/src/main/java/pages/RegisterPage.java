package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class RegisterPage {
    WebDriver driver;

    public RegisterPage(WebDriver driver) {
        this.driver = driver;
    }

    By register = By.linkText("Register");
    By firstName = By.id("FirstName");
    By lastName = By.id("LastName");
    By email = By.id("Email");
    By password = By.id("Password");
    By confirm = By.id("ConfirmPassword");
    By button = By.id("register-button");
    By success = By.className("result");

    public void registerUser(String mail) {
        driver.findElement(register).click();
        driver.findElement(firstName).sendKeys("Test");
        driver.findElement(lastName).sendKeys("User");
        driver.findElement(email).sendKeys(mail);
        driver.findElement(password).sendKeys("Password123");
        driver.findElement(confirm).sendKeys("Password123");
        driver.findElement(button).click();
    }

    public String getMessage() {
        return driver.findElement(success).getText();
    }
}
